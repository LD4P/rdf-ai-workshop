# -*- coding: latin-1 -*-
#
from pyshacl.cli import main


main()
