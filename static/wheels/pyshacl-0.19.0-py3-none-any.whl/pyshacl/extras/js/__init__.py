# -*- coding: utf-8 -*-
#

from .loader import load_into_context


__all__ = ['load_into_context']
